# REACT FIREBASE ADMIN

This project was bootstrapped with [Create React App](https://github.com/facebookincubator/create-react-app).
For project instalation videos and docuemtnation go [here](http://fireadmin.mobidonia.com/).

# DEPLOYMENT INFO

| Project                 | Status | 
|-------------------------|--------|
| [React App Builder demo](https://make.reactappbuilder.com/)  |[![Netlify Status](https://api.netlify.com/api/v1/badges/26ca5271-b8fa-4ce3-bef0-2fc74df669e8/deploy-status)](https://app.netlify.com/sites/trusting-neumann-c10f0d/deploys)    |
| [Fire Admin Demo](https://fireadmin.appadm.in/)          |[![Netlify Status](https://api.netlify.com/api/v1/badges/475fc3ba-37be-4f23-9846-5f34efe3e81a/deploy-status)](https://app.netlify.com/sites/wonderful-hawking-e9f21f/deploys)        |
| AppAdmin Regular        |        |
| [AppAdmin UniExpo](https://apps.appadm.in)  |[![Netlify Status](https://api.netlify.com/api/v1/badges/625cf77d-08c7-4bbe-9c8a-41ac60971ec1/deploy-status)](https://app.netlify.com/sites/elegant-kepler-2170ee/deploys)|
| [CCChangelog](https://make.ccchangelog.com/)              |[![Netlify Status](https://api.netlify.com/api/v1/badges/2de7b14f-5f5e-45d5-b2c6-8bbfc88b7c84/deploy-status)](https://app.netlify.com/sites/pensive-yalow-5071f1/deploys)        |
