import Strings from './strings.js';
export default Strings.expo;
